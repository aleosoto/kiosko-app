# app/config.py
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'z8e7a78e',
    'database': 'kiosko_db'
}
