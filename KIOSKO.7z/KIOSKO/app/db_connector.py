# app/db_connector.py

import mysql.connector
from mysql.connector import Error
from app.config import config

def get_connection():
    try:
        conn = mysql.connector.connect(
            host=config["host"],
            user=config["user"],
            password=config["z8e7a78e"],
            database=config["kisko_db"],
            port=config["3306"]
        )
        return conn
    except Error as e:
        print("ERROR DE CONEXIÓN:", e)
        return None


def execute_query(query, params=None, commit=False):
    conn = get_connection()
    if conn is None:
        print("❌ No se pudo obtener conexión con la base de datos.")
        return []

    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params or ())

        # Commit en operaciones tipo INSERT/UPDATE/DELETE
        if commit:
            conn.commit()

        # SELECT
        if query.strip().upper().startswith("SELECT"):
            return cursor.fetchall()

        return []

    except Error as e:
        print("DB Error:", e)
        return []

    finally:
        try:
            cursor.close()
            conn.close()
        except:
            pass
