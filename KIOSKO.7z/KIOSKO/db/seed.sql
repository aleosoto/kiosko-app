USE kiosko_db;
INSERT INTO productos (nombre, descripcion, precio, categoria) VALUES
('Café Americano', 'Café filtrado 250ml', 25.00, 'Bebida'),
('Café Latte', 'Café con leche 300ml', 35.00, 'Bebida'),
('Sándwich Jamón', 'Sándwich con jamón y queso', 45.00, 'Alimento'),
('Ensalada', 'Ensalada fresca con aderezo', 40.00, 'Alimento'),
('Agua Mineral', 'Botella 500ml', 15.00, 'Bebida');
